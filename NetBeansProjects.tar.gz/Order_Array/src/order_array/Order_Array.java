/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package order_array;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author desarrollador
 */
public class Order_Array {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, SQLException  {
        // TODO code application logic here
        
        Scanner read = new Scanner(System.in);
        
        Connection con = null;
        ResultSet data;
        PreparedStatement query;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
            System.out.println("Conected!");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            query = con.prepareStatement("CREATE TABLE book( id int PRIMARY KEY, name VARCHAR(30) NULL)");
            boolean res = query.execute();
            
            System.out.println(res);
        } catch (Exception e) {
            System.out.println(e);
        }
        
        System.out.println("Ingrese la cantidad de numeros a ingresar: ");
        int length = read.nextInt();
        
    }
    
}
