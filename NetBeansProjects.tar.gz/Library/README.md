#Basic Crud Made in Java Terminal
