/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movies;

/**
 *
 * @author desarrollador
 */
public class movie extends conection{
    
    int num_rows = 0;
    
    public movie(){
        this.conect();
    }
    
    public int insert(String NAME, String GENDER, String AUTHOR){
        try {
            this.query = this.conection.prepareStatement("INSERT INTO lending VALUES(?,?,?,?)");
            this.query.setInt(1, 0);
            this.query.setString(2, NAME);
            this.query.setString(3, GENDER);
            this.query.setString(4, AUTHOR);
            
            this.num_rows = this.query.executeUpdate();
            
            return this.num_rows;
        } catch (Exception e) {
            System.out.println(e);
            return 0;
        }
    }
    
}
