/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movies;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author desarrollador
 */
public class conection{
    
    Connection conection;
    ResultSet data;
    PreparedStatement query;
    
    public boolean conect(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conection = DriverManager.getConnection("jdbc:mysql://localhost/movies", "root", "");
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
        
        return true;
    }
    
    public Connection get_conection(){
        return this.conection;
    }
    
    public boolean close(){
        try {
            this.conection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        }
        return true;
    }
    
}
