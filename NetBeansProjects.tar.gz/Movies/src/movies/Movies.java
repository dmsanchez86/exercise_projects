/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movies;

import java.util.Scanner;

/**
 *
 * @author desarrollador
 */
public class Movies {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner read = new Scanner(System.in);
        
        conection con = new conection();
        movie movie = new movie();
        
        if(con.conect())
            System.out.println("Conected!");
        else
            System.out.println("Can't conected to database!");
        
        try {
            con.get_conection().getCatalog();
            System.out.println("Mi conection is: "+ con.get_conection());
            
            System.out.println("Name Movie: ");
            String name_movie = read.next();
            System.out.println("Gender Movie: ");
            String gender_movie = read.next();
            System.out.println("Author Movie: ");
            String author_movie = read.next();
            
            int num = movie.insert(name_movie, gender_movie, author_movie);
            
            System.out.println(num);
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }
    
}
