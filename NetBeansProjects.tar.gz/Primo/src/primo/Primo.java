/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primo;

import java.util.Scanner;

/**
 *
 * @author desarrollador
 */
public class Primo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner read = new Scanner(System.in);        
        
        int number = 1;
        
        while(number != 0){
            System.out.println("Ingrese un numero: ");
            number = read.nextInt();
            int dn = 0;

            for (int i = number; i > 0; i--)
                if(number % i == 0)
                    dn++;
                
            if(dn == 2)
                System.out.println("\n\tEs Primo el numero "+number);
            else
                System.out.println("\n\tNo es primo el "+number);

        }
        
    
        System.out.println("ingrese la cantidad ");
        int cantidad = read.nextInt();
        
        int[] numbers = new int[cantidad];
        
        for (int i = 0; i < numbers.length; i++) {
            System.out.printf("Ingrese la position %s: ", (i + 1));
            numbers[i] = read.nextInt();
        }
        
        for (int i = 0; i < numbers.length; i++) {
            int count = 0;
            
            for (int j = numbers[i]; j > 0; j--)
                if(numbers[i] % j == 0)
                    count++;
                
            if(count == 2)
                System.out.println("\tEs Primo el numero "+numbers[i]);
            else
                System.out.println("\tNo es primo el "+numbers[i]);
            
        }
    }
    
}
