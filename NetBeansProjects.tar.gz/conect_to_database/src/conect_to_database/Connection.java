/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conect_to_database;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Daniel M. Sanchez
 */
public class Connection {
    
    protected java.sql.Connection con;
    protected ResultSet data;
    protected PreparedStatement query;
    
    public boolean conect(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/people","root","");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
            return false;
        }
        
        return true;
    }
    
    public boolean disconect(){
        try {
            con.close();
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        }
        return true;
    }
    
    public java.sql.Connection get_conection(){
        return con;
    }
    
}
