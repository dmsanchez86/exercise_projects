/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conect_to_database;

import java.util.Scanner;

/**
 *
 * @author Daniel M. Sanchez
 */
public class Conect_to_database {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner read = new Scanner(System.in);
        
        Person person = new Person();
        
        int option = 1, option_function = 0;
        boolean validate = true;
        long id;
        String name, last_name, ocuppation;
        
        while(option != 0){
            System.out.println("\t\tPEOPLE");
            System.out.println("\n\t1) New Person");
            System.out.println("\t2) All People");
            System.out.println("\t3) Your Person");
            System.out.println("\t0) Go Out!");
            option = read.nextInt();
            
            switch(option){
                case 1:
                    System.out.println("\n\t\tNEW PERSON");
                    System.out.print("\nId Person: ");
                    id = read.nextLong();
                    System.out.print("Name Person: ");
                    name = read.next();
                    System.out.print("Last Name: ");
                    last_name = read.next();
                    System.out.print("Ocuppation: ");
                    ocuppation = read.next();
                    
                    if(person.new_(id, name, last_name, ocuppation) > 0)
                        System.out.println("\n\tNEW PERSON "+ person.name().toUpperCase()+ " ADDED SUCCESFUL!\n");
                    else
                        System.out.println("\n\tCAN'T ADD NEW PERSON\n");
                    break;
                case 2:
                    String[] persons = person.all();
                    
                    System.out.println("\n\t\tALL PEOPLE\n");
                    for (int i = 0; i < persons.length; i++) {
                        System.out.println(persons[i]);
                    }
                    System.out.println("\n");
                    break;
                case 3:
                    System.out.println("\n\t\tYOUR PERSON\n");
                    
                    System.out.print("Write your id: ");
                    id = read.nextInt();
                    
                    String[] d = person.find(id);
                    
                    if(d != null){
                        
                        person = new Person(Integer.parseInt(d[0]), d[1], d[2], d[3]);
                        
                        while(option_function != 0){
                            System.out.println("\n\tOPTIONS\n");
                            System.out.println("\t1) Say your name!");
                            System.out.println("\t2) Say your last_name!");
                            System.out.println("\t3) Say your ocuppation!");
                            System.out.println("\t0) Go Out!");
                            option_function = read.nextInt();

                            switch(option_function){
                                case 1:
                                    person.say("name");
                                    break;
                                case 2:
                                    person.say("last_name");
                                    break;
                                case 3:
                                    person.say("ocuppation");
                                    break;
                            }
                        }
                    }else{
                        System.out.println("Your id isn't exists in database!");
                    }
                    
                    break;
            }
        }
        
    }
    
}
