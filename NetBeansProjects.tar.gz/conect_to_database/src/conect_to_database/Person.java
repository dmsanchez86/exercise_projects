/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conect_to_database;

import java.sql.SQLException;

/**
 *
 * @author Daniel M. Sanchez
 */
public class Person extends Connection{
    private long id;
    private String name;
    private String last_name;
    private String ocuppation;
    
    public Person(){
    }
    
    public Person(long ID, String NAME, String LAST_NAME, String OCUPPATION){
        id = ID;
        name = NAME;
        last_name = LAST_NAME;
        ocuppation = OCUPPATION;
    }
    
    public int new_(long ID, String NAME, String LAST_NAME, String OCUPPATION){
        id = ID;
        name = NAME;
        last_name = LAST_NAME;
        ocuppation = OCUPPATION;
        
        int num = 0;
        
        try {
            conect();
            
            query = con.prepareStatement("INSERT INTO person VALUES(?, ?, ?, ?)");
            query.setLong(1, id);
            query.setString(2, name);
            query.setString(3, last_name);
            query.setString(4, ocuppation);
            
            num = query.executeUpdate();
            disconect();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        }
        return num;
    }
    
    public String name(){
        return name;
    }

    public String[] all() {
        String[] persons = null;
        int count = 0;
        
        try {
            conect();
            
            query = con.prepareStatement("SELECT COUNT(*) AS number_people FROM person");
            data = query.executeQuery();
            
            while(data.next()){
                count = data.getInt("number_people");
            }
            
            persons = new String[count];
            count = 0;
            
            query = con.prepareStatement("SELECT * FROM person");
            data = query.executeQuery();
            
            System.out.println(data.getFetchSize());
            
            while(data.next()){
                persons[count] = "ID: "+ data.getInt("id") 
                        +" - NAME: "+ data.getString("name") 
                        + " - LAST NAME: "+ data.getString("last_name")  
                        + " - OCUPPATION: "+ data.getString("ocuppation");
                count++;
            }
            
            disconect();
            
        } catch (SQLException e) {
            System.out.println("");
            System.out.println(e);
            return null;
        }
        
        return persons;
    }

    public String[] find(long id) {
        String[] data_person = null;
        
        try {
            
            conect();
            data_person = new String[4];
            
            query = con.prepareStatement("SELECT * FROM person WHERE id = ?");
            query.setLong(1, id);
            data = query.executeQuery();
            
            while(data.next()){
                data_person[0] = ""+data.getInt("id");
                data_person[1] = data.getString("name");
                data_person[2] = data.getString("last_name");
                data_person[3] = data.getString("ocuppation");
            }
            
            return data_person;
            
        } catch (SQLException | NumberFormatException e) {
            System.out.println(e);
            return null;
        }
    }

    public void say(String param) {
        if(null != param)
            switch (param) {
            case "name":
                System.out.println("My name is "+ name);
                break;
            case "last_name":
                System.out.println("My last name is " + last_name);
                break;
            case "ocuppation":
                System.out.println("My ocuppation is "+ ocuppation);
                break;
        }
    }
    
}
