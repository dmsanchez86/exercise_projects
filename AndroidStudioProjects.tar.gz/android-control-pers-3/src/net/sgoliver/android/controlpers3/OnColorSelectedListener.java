package net.sgoliver.android.controlpers3;

public interface OnColorSelectedListener 
{
	void onColorSelected(int color);
}
