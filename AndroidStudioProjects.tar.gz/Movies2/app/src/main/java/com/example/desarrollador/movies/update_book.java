package com.example.desarrollador.movies;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class update_book extends AppCompatActivity {

    String name_gender = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_book);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        conection con = new conection(this, "database.db", null, 1);
        final SQLiteDatabase db = con.getWritableDatabase();

        // Variables
        final EditText txt_id = (EditText) findViewById(R.id.txt_id_update);
        final EditText txt_name = (EditText) findViewById(R.id.txt_name_update);
        final EditText txt_gender = (EditText) findViewById(R.id.txt_gender_update);
        ListView list_genders = (ListView) findViewById(R.id.list_movies_update);
        final Button btn_update = (Button) findViewById(R.id.btn_update);
        final Button btn_delete = (Button) findViewById(R.id.btn_delete);
        final Button btn_cancel = (Button) findViewById(R.id.btn_cancel);

        // List of names gender movies
        String[] list_gender_movies = { "Scary","Action","Funny" };

        ArrayAdapter<String> list = new ArrayAdapter<String>(this, R.layout.genders_movie, list_gender_movies);

        list_genders.setAdapter(list);
        txt_gender.setEnabled(false);

        list_genders.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView t = (TextView) view;
                txt_gender.setText(t.getText().toString());
                name_gender = t.getText().toString();
            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setVisibility(View.INVISIBLE);

        Bundle extras = getIntent().getExtras();
        System.out.println("======================================");
        System.out.println(extras);
        if (extras != null) {
            String[] value = extras.getStringArray("data_book");

            txt_id.setEnabled(false);
            txt_id.setText("" + value[0].toString());
            txt_name.setText(""+value[1].toString());
            txt_gender.setText(""+value[2].toString());
            name_gender = value[2].toString();

        }

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = txt_id.getText().toString();
                String name = txt_name.getText().toString();
                String gender = txt_gender.getText().toString();
                String str = "";

                if (id.equals("")) {
                    str = "The Id can't be empty!";
                    txt_id.requestFocus();
                    Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
                } else if (name.equals("")) {
                    str = "The Name can't empty!";
                    Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
                    txt_name.requestFocus();
                } else if (txt_gender.equals("")) {
                    str = "Select item from list Gender Movie!";
                    Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
                } else {
                    str = "Update Movie in Database";

                    String sql = "UPDATE movies SET name = '"+ name +"', gender = '"+ name_gender +"' WHERE id = '"+ id +"'";
                    db.execSQL(sql);

                    Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();

                    txt_id.setText("");
                    txt_name.setText("");
                    txt_gender.setText("");

                    Intent i = new Intent(getApplicationContext(), all_movies.class);
                    startActivity(i);
                }
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = txt_id.getText().toString();

                Toast.makeText(getApplicationContext(), "id "+id, Toast.LENGTH_SHORT).show();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), all_movies.class);
                startActivity(i);
            }
        });

    }

}
