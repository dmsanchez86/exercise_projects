/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.controlpers1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}