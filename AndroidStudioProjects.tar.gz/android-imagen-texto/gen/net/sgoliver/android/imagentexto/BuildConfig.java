/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.imagentexto;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}