/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.holausuario;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}