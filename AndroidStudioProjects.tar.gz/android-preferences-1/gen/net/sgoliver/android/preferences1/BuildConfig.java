/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.preferences1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}