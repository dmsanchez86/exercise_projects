/** Automatically generated file. DO NOT MODIFY */
package net.sgoliver.android.ficheros;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}